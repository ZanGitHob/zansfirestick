package zansfirestick;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import zansfirestick.proxy.CommonProxy;
import zansfirestick.registry.ModItems;
import zansfirestick.registry.ModRecipes;

import zansfirestick.CommonProxy;
import zansfirestick.ZansFirestick;

@Mod(
    modid = ZansFirestick.MODID,
    name = ZansFirestick.NAME,
    version = ZansFirestick.VERSION,
    acceptedMinecraftVersions = "[1.10.2]"
)
public class ZansFirestick {
    public static final String MODID = "zansfirestick";
    public static final String NAME = "ZansFirestick";
    public static final String VERSION = "1.0";

    @Mod.Instance(MODID)
    public static ZansFirestick instance;

    @SidedProxy(
        clientSide = "zansfirestick.proxy.ClientProxy",
        serverSide = "zansfirestick.proxy.CommonProxy"
    )
    public static CommonProxy proxy;

    public static final CreativeTabs TAB = new CreativeTabs(MODID) {
        @Override
        public Item func_78016_d() {
            return ModItems.firestick;
        }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ModItems.init();
        ModItems.register();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        ModRecipes.register();
        proxy.registerRenders();
    }
}
