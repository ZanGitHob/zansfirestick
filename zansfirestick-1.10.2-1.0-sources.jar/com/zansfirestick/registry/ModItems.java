package zansfirestick.registry;

import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;
import zansfirestick.ZansFirestick;
import zansfirestick.item.ItemFirestick;

import zansfirestick.registry.ModItems;

public class ModItems {
    public static Item firestick;

    public static void init() {
        firestick = new ItemFirestick().setUnlocalizedName("firestick");
    }

    public static void register() {
        firestick.setRegistryName(new ResourceLocation(ZansFirestick.MODID, "firestick"));
        GameRegistry.register(firestick);
    }

    private ModItems() {
    }
}
