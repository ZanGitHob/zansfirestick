package zansfirestick.registry;

import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.oredict.ShapelessOreRecipe;

import zansfirestick.registry.ModRecipes;

public class ModRecipes {
    public static void register() {
        GameRegistry.addRecipe(
            (IRecipe) new ShapelessOreRecipe(
                new ItemStack(ModItems.firestick),
                "stickWood",
                "stickWood"
            )
        );
    }

    private ModRecipes() {
    }
}
