package zansfirestick.item;

import java.util.Random;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import zansfirestick.ZansFirestick;

import zansfirestick.item.ItemFirestick;

public class ItemFirestick extends Item {
    private final Random random = new Random();

    public ItemFirestick() {
        func_77656_e(15);
        func_77625_d(1);
        func_77637_a(ZansFirestick.TAB);
    }

    @Override
    public EnumActionResult func_180614_a(
        ItemStack stack,
        EntityPlayer playerIn,
        World worldIn,
        BlockPos pos,
        EnumHand hand,
        EnumFacing facing,
        float hitX,
        float hitY,
        float hitZ
    ) {
        pos = pos.func_177972_a(facing);

        if (playerIn.func_175151_a(pos, facing, stack) && worldIn.func_175623_d(pos)) {
            worldIn.func_184133_a(
                playerIn,
                pos,
                SoundEvents.field_187649_bu,
                SoundCategory.BLOCKS,
                1.0F,
                random.nextFloat() * 0.4F + 0.8F
            );

            if (!worldIn.field_72995_K) {
                if (random.nextFloat() < 0.15F) {
                    worldIn.func_180501_a(pos, Blocks.field_150480_ab.func_176223_P(), 3);
                }

                stack.func_77972_a(1, (EntityLivingBase) playerIn);
            }

            return EnumActionResult.SUCCESS;
        }

        return EnumActionResult.FAIL;
    }
}
