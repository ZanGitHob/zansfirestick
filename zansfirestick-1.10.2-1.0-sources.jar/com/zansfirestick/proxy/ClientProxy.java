package zansfirestick.proxy;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import zansfirestick.ZansFirestick;
import zansfirestick.registry.ModItems;

import zansfirestick.proxy.ClientProxy;

public class ClientProxy extends CommonProxy {
    @Override
    public void registerRenders() {
        Minecraft.func_71410_x()
            .func_175599_af()
            .func_175037_a()
            .func_178086_a(
                ModItems.firestick,
                0,
                new ModelResourceLocation(
                    ZansFirestick.MODID + ":firestick",
                    "inventory"
                )
            );
    }
}
