package zansfirestick.proxy;
import zansfirestick.proxy.CommonProxy;


public class CommonProxy {
    public void registerRenders() {
    }
}
